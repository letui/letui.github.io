package com.example.eurekafeign;

import org.springframework.stereotype.Component;

@Component
public class HiServiceImpl implements HiService{

    @Override
    public String sayHello() {
        return "GOOD-ERROR";
    }
}
